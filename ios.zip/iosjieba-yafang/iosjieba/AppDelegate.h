//
//  AppDelegate.h
//  iosjieba
//
//  Created by yanyiwu on 14/12/23.
//  Copyright (c) 2014年 yanyiwu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

