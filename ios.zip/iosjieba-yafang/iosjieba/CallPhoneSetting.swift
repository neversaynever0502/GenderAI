//
//  CallPhoneSetting.swift
//  iosjieba
//
//  Created by Ya Fang Cheng on 2016/12/3.
//  Copyright © 2016年 yanyiwu. All rights reserved.
//

import UIKit
import CoreMotion

class CallPhoneSetting: UIViewController {
    let prefs:UserDefaults = UserDefaults.standard
    @IBOutlet weak var callNumber: UITextField!
    @IBOutlet weak var switchOn: UISwitch!
    
    
    
    
    //加速计管理者-所有的操作都会由这个motionManager接管
//        var cmm:CMMotionManager!
//    lazy  var  cmm  =  CMMotionManager()
//    var  queue  =  OperationQueue()
    let motionManager = CMMotionManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        // Do any additional setup after loading the view.
        
        
        

        if prefs.object(forKey: "phone") != nil{
            callNumber.text = prefs.object(forKey: "phone") as? String
        }
        
        if prefs.object(forKey: "on") != nil{
            let xx = prefs.object(forKey: "on") as? Bool
            if xx == true{
                switchOn.isOn = true
//                StartAccerometer()
//                StartGyrometer()
                if let url = NSURL(string: "tel:\(callNumber.text!)") {
                    UIApplication.shared.openURL(url as URL)
                }
            }else{
                switchOn.isOn = false
//                StopAcceler()
//                StopGyro()
            }
        }else{
            switchOn.isOn = false
//            StopAcceler()
//            StopGyro()
        }
//
//        
//        
////        //陀螺儀偵測
//        if motionManager.isGyroAvailable {
//            motionManager.deviceMotionUpdateInterval = 0.2;
//            motionManager.startDeviceMotionUpdates()
//            
//            motionManager.gyroUpdateInterval = 0.2
//            motionManager.startGyroUpdatesToQueue(OperationQueue.currentQueue!) {
//                [weak self] (gyroData: CMGyroData!, error: NSError!) in
//                
//                self?.outputRotationData(gyroData.rotationRate)
//                if error != nil {
//                    print("\(error)")
//                }
//            }
//        } else {
//            // alert message
//        }
        
        
    }
    
   
    
    @IBAction func phoneText(_ sender: Any) {
        if callNumber.text != nil{
            prefs.set(callNumber.text, forKey: "phone")
        }
    }

    @IBAction func switchClick(_ sender: Any) {
        
        switchOn.isOn  = !switchOn.isOn
        
        if switchOn.isOn == true{
            prefs.set(true, forKey: "on")
            
//            StartAccerometer()
//            StartGyrometer()
            
            
            
            
        }else{
            prefs.set(false, forKey: "on")
            
//            StopAcceler()
//            StopGyro()
            
        }
    }
    
//    func StartAccerometer(){ //（一）、以下是获取加速度数据的使用方法
//        
//        cmm.accelerometerUpdateInterval = 1 //获取频率，每1S获取一次
//        if cmm.isAccelerometerAvailable && !cmm.isAccelerometerActive{ //判断传感器是否为可用？且没活动
//            
//            cmm.startAccelerometerUpdates(to: OperationQueue(), withHandler: {(data:CMAccelerometerData?,err:NSError?) in
//                //传入加速度传感器数据
//                
//                print("加速度数据：\(data)") //打印加速度数据
//            } as! CMAccelerometerHandler)
//        }else{
//            print("加速度传感器不可用")
//        }
//    }
//    
//    func StartGyrometer(){ //（二）、以下是获取陀螺仪数据的使用方法
////        cmm.gyroUpdateInterval = 1 //获取陀螺仪数据频率
//        
//        
////        if cmm.isGyroAvailable && !cmm.isGyroActive{ //判断传感器是否为可用？且没活动
////            cmm.startGyroUpdates(to: OperationQueue(), withHandler: {
////                (data:CMGyroData?,err:NSError?) in
////                print("陀螺仪数据：\(data)")
////            } as! CMGyroHandler)
////            
////        }else{
////            print("陀螺仪传感器不可用") }
//        
//        
//        
//        if  cmm.isGyroAvailable{
//            
//            if  cmm.isGyroActive  ==  false{
//                
//                cmm.gyroUpdateInterval  =  1.0  /  40.0
//                
//                cmm.startGyroUpdates(to: queue,
//                                                withHandler:  {(data:  CMGyroData!,  error:  NSError!)  in
//                                                    
//                                                    print("Gyro  Rotation  x  =  \(data.rotationRate.x)")
//                                                    print("Gyro  Rotation  y  =  \(data.rotationRate.y)")
//                                                    print("Gyro  Rotation  z  =  \(data.rotationRate.z)")
//                                                    
//                } as! CMGyroHandler)
//                
//            }  else  {
//                print("Gyro  is  already  active")
//            }
//            
//        }  else  {
//            print("Gyro  isn't  available")
//        }
//        
//        
//    }
//    
//    func StopAcceler(){
//        if cmm.isAccelerometerActive{ //如果加速器传感器还在活动
//            cmm.stopAccelerometerUpdates() //停止侦听加速器传感器
//            
//        }
//    }
//    
//    func StopGyro(){
//        if cmm.isGyroActive {
//            cmm.stopGyroUpdates()
//        }
//    }
    
//    func motionMove(){
//        //------ CoreMotion 加速计
//        var accelerometerData = accelerometerData
//        var error = error
//        motionManager = CMMotionManager()//注意CMMotionManager不是单例
//        motionManager.accelerometerUpdateInterval = 0.1//设置读取时间间隔
//        
//        if motionManager.isAccelerometerAvailable//判断是否可以使用加速度计
//        {
//            //获取主线程并发队列,在主线程里跟新UI
//            motionManager.startAccelerometerUpdatesToQueue(OperationQueue.mainQueue, withHandler: { ( accelerometerData:CMAccelerometerData?, error:NSError?) -> Void in
//                
//                                 if error != nil
//                                 {
//                                         self.motionManager.stopAccelerometerUpdates()//停止使用加速度计
//                                     }else
//                                 {
//                    
//                                         print( "x:\(accelerometerData!.acceleration.x)",
//                                          "Y:\(accelerometerData!.acceleration.y)",
//                                          "Z:\(accelerometerData!.acceleration.z)")
//                                     }
//                             } as! CMAccelerometerHandler)
//            
//            
//                     }else
//                 {
//                         let aler = UIAlertView(title: "您的设备不支持加速计", message: nil, delegate: nil, cancelButtonTitle: "OK")
//                         aler.show()
//                     }
//        
//        
//        
//                 //感知设备方向-开启监听设备方向
//                 UIDevice.current.beginGeneratingDeviceOrientationNotifications()
//                 //添加通知，监听设备方向改变
//                NotificationCenter.default.addObserver(self, selector: Selector("receivedRotation"), name: UIDeviceOrientationDidChangeNotification, object: nil)
//                //关闭监听设备方向
//                 UIDevice.current.endGeneratingDeviceOrientationNotifications()
//        
//    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
//    // MARK: - 判断设备方向代理方法
//         func receivedRotation()
//         {
//             var device = UIDevice.currentDevice()
//    
//             if device.orientation == UIDeviceOrientation.Unknown
//             {
//                 orientationLabel.text = "Unknown"
//             }
//             else if device.orientation == UIDeviceOrientation.Portrait
//         {
//                 orientationLabel.text = "Portrait"
//             }
//             else if device.orientation == UIDeviceOrientation.PortraitUpsideDown
//             {
//                  orientationLabel.text = "PortraitUpsideDown"
//             }
//             else if device.orientation == UIDeviceOrientation.LandscapeLeft
//             {
//                  orientationLabel.text = "LandscapeLeft"
//             }
//             else if device.orientation == UIDeviceOrientation.LandscapeRight
//             {
//                  orientationLabel.text = "LandscapeRight"
//             }else if device.orientation == UIDeviceOrientation.FaceUp
//             {
//                  orientationLabel.text = "FaceUp"
//             }
//             else  if device.orientation == UIDeviceOrientation.FaceDown
//             {
//                  orientationLabel.text = "FaceDown"
//             }
//         }
//    
//         // MARK: - 摇晃事件
//         override func motionBegan(motion: UIEventSubtype, withEvent event: UIEvent) {
//        
//                print("motionBegan")//开始摇晃
//             }
//    
//         override func motionEnded(motion: UIEventSubtype, withEvent event: UIEvent) {
//                 print("motionEnded")//摇晃结束
//             }
//    
//    
//         override func motionCancelled(motion: UIEventSubtype, withEvent event: UIEvent) {
//                 print("motionCancelled")//摇晃被意外终止
//             }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
