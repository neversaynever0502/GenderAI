////
////  GoogleApiDataFetcher.swift
////  iosjieba
////
////  Created by Ya Fang Cheng on 2016/12/3.
////  Copyright © 2016年 yanyiwu. All rights reserved.
////
//
//import Foundation
//
//class GoogleApiDataFetcher{
////: AFHTTPSessionManager {
//
//    static let sharedInstance: GoogleApiDataFetcher = {
//        let baseURL = NSURL(string: "https://maps.googleapis.com/maps/api/place")
//        
//        let config = URLSessionConfiguration.default
//        config.httpAdditionalHeaders = ["User-Agent": "Ancall iOS"]
//        
//        //設置 cache size. 其中內存 cache size: 10M, 磁碟 cache size: 5M
//        let cache = URLCache(memoryCapacity: 10 * 1024 * 1024, diskCapacity: 50 * 1024 * 1024, diskPath: nil)
//        config.urlCache = cache
//        
//        
//        let sharedInstance = GoogleApiDataFetcher(baseURL: baseURL, sessionConfiguration: config)
////        sharedInstance.responseSerializer = AFJSONResponseSerializer()
////        sharedInstance.requestSerializer = AFJSONRequestSerializer()
////        
////        // 忽略不合法的 ssl 簽證
////        let security = AFSecurityPolicy()
////        security.allowInvalidCertificates = true
////        security.validatesDomainName = false
////        sharedInstance.securityPolicy = security
//        
//        return sharedInstance
//        
//    }()
//    
//    
//    func fetchPlaceNearByCoordinate(coordinate: CLLocationCoordinate2D, searchTypes types: String?, nextPageToken pagetoken: String?,  completion: @escaping (_ responseObject: AnyObject?, _ error: NSError?) -> Void){
//        let param: NSMutableDictionary = ["location": "\(coordinate.latitude),\(coordinate.longitude)"
//            //            ,"radius": 5000
//            , "rankby": "distance"
//            , "key": "AIzaSyBEsDXekUK88TKVPVJ0bUSg7gWuPO4wMvU"]
//        
//        if let types = types{
//            param["types"] = types
//        }
//        
//        if let pagetoken = pagetoken{
//            param["pagetoken"] = pagetoken
//        }
//        
//        
//        
////        self.GET("nearbysearch/json", parameters: param, progress: nil, success: {
////            let httpResponse = $0.0.response as? NSHTTPURLResponse
////            if let httpResponse = httpResponse, httpResponse.statusCode == 200{
////                completion(responseObject: $0.1, error: nil)
////            }else{
////                completion(responseObject: nil, error: nil)
////            }
////        }) { (NSURLSessionDataTask, NSError) in
////            #if DEBUG
////                NSLog("\(#function) error: \(NSError.userInfo["NSErrorFailingURLKey"]) \(NSError.localizedDescription)")
////            #endif
////            completion(responseObject: nil, error: nil)
////        }
//        
//    }
//    
//    func fetchPlaceDetailDataByPlaceId(placeId: String, completion:@escaping (_ responseObject: AnyObject?, _ error: NSError?) -> Void){
//        let param = ["placeid": placeId, "key": "AIzaSyBEsDXekUK88TKVPVJ0bUSg7gWuPO4wMvU"]
//        
////        self.GET("details/json", parameters: param, progress: nil, success: {
////            let httpResponse = $0.0.response as? NSHTTPURLResponse
////            if let httpResponse = httpResponse, httpResponse.statusCode == 200{
////                completion(responseObject: $0.1, error: nil)
////            }else{
////                completion(responseObject: nil, error: nil)
////            }
////        }) { (NSURLSessionDataTask, NSError) in
////            #if DEBUG
////                NSLog("\(#function) error: \(NSError.userInfo["NSErrorFailingURLKey"]) \(NSError.localizedDescription)")
////            #endif
////            completion(responseObject: nil, error: nil)
////        }
//    }
//    
//}
