//
//  LocationSearchListTableViewCell.swift
//  iosjieba
//
//  Created by Ya Fang Cheng on 2016/12/3.
//  Copyright © 2016年 yanyiwu. All rights reserved.
//

import UIKit

class LocationSearchListTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var addrLabel: UILabel!
    @IBOutlet weak var phonLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    

    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}

