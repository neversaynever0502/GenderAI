//
//  NewTest.swift
//  iosjieba
//
//  Created by Ya Fang Cheng on 2016/12/3.
//  Copyright © 2016年 yanyiwu. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Charts

class NewTest: UIViewController {
let prefs:UserDefaults = UserDefaults.standard
    
    @IBOutlet weak var backImage: UIImageView!
    
    @IBOutlet weak var percentShow: UILabel!
    
//    @IBOutlet weak var pieChartView: PieChartView!
    
    let imageAll = ["detail2_2＿high","detail2_2＿middle","detail2_2＿low","detail2_2＿perfect"]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        // Do any additional setup after loading the view.
        
        //get question to array
        let mySwiftData = prefs.value(forKey: "data") as! String
        print ("data is \(mySwiftData)")
        
        //去除前後[]
        let typeGet = mySwiftData.substring(from: mySwiftData.index(after: mySwiftData.startIndex))
        let typeGet2 = typeGet.substring(to: typeGet.index(before: typeGet.endIndex))
        
        
        let bb = typeGet2.components(separatedBy: ",")//就變成[String]
        //先去除空白
        
        let bbA:Array = bb.map { (insedeBA) -> String in
            if insedeBA.hasPrefix(" "){
                let insedeBAGET = insedeBA.substring(from: insedeBA.index(after: insedeBA.startIndex))
                
                return insedeBAGET
            }else{
                return insedeBA
            }
            
            
        }
        
        //去除""
        let bbB:Array = bbA.map { (insideB) -> String in
            let bbGet = insideB.substring(from: insideB.index(after: insideB.startIndex))
            let bbGet2 = bbGet.substring(to: bbGet.index(before: bbGet.endIndex))
            return bbGet2
        }
        
        print("array是\(bbB)")
        prefs.set(bbB, forKey: "FinalProbArray")
        self.prefs.synchronize()
        
        //
        getfirebaseLaw()
        
        //
//        let months = ["Jan", "Feb"]
//        let unitsSold = [20.0, 4.0]
//        
//        setChart(dataPoints: months, values: unitsSold)
    }
    
    var keyAll = Array<Double>()
    
    func getfirebaseLaw(){
        FIRDatabase.database().reference().child("discriminations").observe(.childAdded, with: { (snapshot) in
            var matches = 0
            // Get value
            let value = snapshot.value as? [String]
            print("snapshot.value是\(snapshot.value)")
            
            
            
            let FinalProbArray = self.prefs.value(forKey: "FinalProbArray") as! [String]
            print ("FinalProbArray is \(FinalProbArray)")
            
            //相似度
            for y in 0...FinalProbArray.count-1 {
                
                for x in 0...(value?.count)!-1{
                    
                    if FinalProbArray[y] == value?[x] {
                        matches += 1
                    }
                }
            }
            
            
            Double(matches) / Double(FinalProbArray.count)
            
            print("相似度是\(Double(matches) / Double(FinalProbArray.count))")
            
            
            let a = Double(matches) / Double(FinalProbArray.count)
            
//            let months = ["J", "F","k"]
//            let unitsSold = [a, 0.5, 0.5]
//            
//            self.setChart(dataPoints: months, values: unitsSold)
            
            self.percentShow.text = "\(Int(Double(matches)*100 / Double(FinalProbArray.count)))"
          
            if a > 0.4{
                self.backImage.image = UIImage(named:"\(self.imageAll[0])")
            }else if a > 0.19 {
                self.backImage.image = UIImage(named:"\(self.imageAll[1])")
            }else if a > 0{
                self.backImage.image = UIImage(named:"\(self.imageAll[2])")
            }else{
                self.backImage.image = UIImage(named:"\(self.imageAll[3])")
            }
     
            
        }){ (error) in
            print(error.localizedDescription)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    func setChart(dataPoints: [String], values: [Double]) {
//        
//        var dataEntries: [ChartDataEntry] = []
//        
//        for i in 0..<dataPoints.count {
//            let dataEntry = ChartDataEntry(x: values[i], y: Double(i))
////                ChartDataEntry(x: values[i], y: Double(i))
//            
//            dataEntries.append(dataEntry)
//        }
//        
//        let pieChartDataSet = PieChartDataSet(values: dataEntries, label: "")
////        let pieChartDataSet = PieChartDataSet(values: dataEntries, label: "")
//        let pieChartData = PieChartData(dataSet: pieChartDataSet)
//            
////            PieChartData(xVals: dataPoints, dataSet: pieChartDataSet)
//        pieChartView.data = pieChartData
//        
//        var colors: [UIColor] = []
//        
//        for _ in 0..<dataPoints.count {
//            let red = Double(arc4random_uniform(256))
//            let green = Double(arc4random_uniform(256))
//            let blue = Double(arc4random_uniform(256))
//            
//            let color = UIColor(red: CGFloat(red/255), green: CGFloat(green/255), blue: CGFloat(blue/255), alpha: 1)
//            colors.append(color)
//        }
//        
//        pieChartDataSet.colors = colors
//        
//        
//       
//        
//    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
