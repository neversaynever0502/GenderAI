//
//  ViewController.m
//  iosjieba
//
//  Created by yanyiwu on 14/12/23.
//  Copyright (c) 2014年 yanyiwu. All rights reserved.
//

#import "ViewController.h"
#include "Segmentor.h"




@interface ViewController ()

@end

@implementation ViewController

//NSString *heyhey = @"";



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    CGRect bounds = self.view.bounds;
    
    // label
    
//    UILabel* label = [[UILabel alloc] initWithFrame:CGRectMake(80, 220, 300, 40)];
//    label.text = @"親愛的～你有什麼問題呢？";
//    label.tag = 100;
//    label.textAlignment = NSTextAlignmentCenter;
//    label.textColor = [UIColor  whiteColor];
//    label.numberOfLines = 0;
//    label.adjustsFontSizeToFitWidth = true;
//    label.lineBreakMode = NSLineBreakByWordWrapping;
    
//    label.center = CGPointMake(CGRectGetMidX(bounds), CGRectGetMidY(bounds) * 1 / 4);
//    [self.view addSubview:label];
    
    
    CGRect textViewFrame = CGRectMake(40.0, 290.0, 350.0, 430.0);
    UITextView *textView = [[UITextView alloc] initWithFrame:textViewFrame];
    
//    textView.center = CGPointMake(CGRectGetMidX(bounds), CGRectGetMidY(bounds) * 1 / 2);
    textView.returnKeyType = UIReturnKeyDone;
//    textView.backgroundColor = [UIColor  whiteColor];
    textView.backgroundColor = [UIColor
                                colorWithRed:1.0
                                green:0.0
                                blue:0.0
                                alpha:0.0];
    [textView setTextColor:[UIColor whiteColor]];
     [textView setFont:[UIFont systemFontOfSize:24]];
    textView.delegate = self;
    [self.view addSubview:textView];
    
    
//    self.view.backgroundColor = [UIColor blueColor];
    
    NSString *dictPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"iosjieba.bundle/dict/jieba.dict.small.utf8"];
    NSString *hmmPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"iosjieba.bundle/dict/hmm_model.utf8"];
    NSString *userDictPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"iosjieba.bundle/dict/user.dict.utf8"];
    
    NSLog(@"%@",dictPath);
    NSLog(@"%@",hmmPath);
    NSLog(@"%@",hmmPath);
    
    const char *cDictPath = [dictPath UTF8String];
    const char *cHmmPath = [hmmPath UTF8String];
    const char *cUserDictPath = [userDictPath UTF8String];
    
    
    JiebaInit(cDictPath, cHmmPath, cUserDictPath);
    
}

- (void)ppp {
   
    
    // Dispose of any resources that can be recreated.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

- (BOOL)becomeFirstResponder {
    return YES;
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    NSLog(@"textViewShouldBeginEditing:");
    return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
    NSLog(@"textViewDidBeginEditing:");
    //textView.backgroundColor = [UIColor greenColor];
}


- (BOOL)textViewShouldEndEditing:(UITextView *)textView{
    NSLog(@"textViewShouldEndEditing:");
    //textView.backgroundColor = [UIColor whiteColor];
    const char* sentence = [textView.text UTF8String];
//    const char* sentence = [@"今天天气不错，适合去研究室打排球，扑克牌好好玩" UTF8String];
    std::vector<std::string> words;
    JiebaCut(sentence, words);
    std::string result;
    result << words;
    textView.text = [NSString stringWithUTF8String:result.c_str()] ;
//    heyhey = [NSString stringWithUTF8String:result.c_str()];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setValue:textView.text forKey:@"data"];
    [defaults synchronize];
    
    [self performSegueWithIdentifier:@"goNext" sender:self];
    textView.text = @"";
    return YES;
    
}

- (void)textViewDidEndEditing:(UITextView *)textView{
    NSLog(@"textViewDidEndEditing:");
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    NSCharacterSet *doneButtonCharacterSet = [NSCharacterSet newlineCharacterSet];
    NSRange replacementTextRange = [text rangeOfCharacterFromSet:doneButtonCharacterSet];
    NSUInteger location = replacementTextRange.location;
    
    if (textView.text.length + text.length > 140){
        if (location != NSNotFound){
            [textView resignFirstResponder];
        }
        return NO;
    }
    else if (location != NSNotFound){
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

- (void)textViewDidChange:(UITextView *)textView{
    NSLog(@"textViewDidChange:");
}

- (void)textViewDidChangeSelection:(UITextView *)textView{
    NSLog(@"textViewDidChangeSelection:");
}
- (IBAction)clickButton:(id)sender {
   


}
 
//- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
//    if ([segue.identifier isEqualToString:@"goNext"]) {
//        
//        ViewController *destViewController = segue.destinationViewController;
//       
//    }
//}

    
@end

