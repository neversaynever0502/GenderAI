//
//  ViewController2.swift
//  iosjieba
//
//  Created by rubl333 on 2016/11/20.
//  Copyright © 2016年 yanyiwu. All rights reserved.
//

import UIKit
import FirebaseDatabase
import GoogleMaps
import GooglePlaces

class ViewController2: UIViewController, UITableViewDataSource, UITableViewDelegate, CLLocationManagerDelegate{

    let prefs:UserDefaults = UserDefaults.standard
    
    @IBOutlet weak var LawShow: UITextView!
    @IBOutlet weak var LawShowLow: UITextView!
    //self location
    var currentLocation: CLLocation?
//    var googleApiDataFetcher: GoogleApiDataFetcher?
    var locationManager: CLLocationManager?
    var currentAuthorizationStatus: CLAuthorizationStatus?{
        didSet{
            self.perpareStartUpdatingLocation()
        }
    }
    
    
    
//police place
    @IBOutlet weak var tableView: UITableView!
    var searchType = "police"
    
    
    
    var results: NSArray?{
        didSet{
            self.tableView.reloadData()
        }
    }
    var pageToken: String?
    
    var placesClient: GMSPlacesClient?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self location
        self.locationManager = CLLocationManager()
        self.locationManager?.delegate = self
        self.locationManager?.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager?.requestWhenInUseAuthorization()
        self.locationManager?.requestAlwaysAuthorization()
        
//        self.googleApiDataFetcher = GoogleApiDataFetcher.sharedInstance
        
        
        //police
//        self.placesClient = GMSPlacesClient()
        
        
        
//        self.googleApiDataFetcher = GoogleApiDataFetcher.sharedInstance
        
//        self.fetechGoogleApiDataWithPageToken(pageToken: "")
        

        
        
        //get question to array
        let mySwiftData = prefs.value(forKey: "data") as! String
        print ("data is \(mySwiftData)")
        
        //去除前後[]
        let typeGet = mySwiftData.substring(from: mySwiftData.index(after: mySwiftData.startIndex))
        let typeGet2 = typeGet.substring(to: typeGet.index(before: typeGet.endIndex))
        
        
        let bb = typeGet2.components(separatedBy: ",")//就變成[String]
        //先去除空白
        
        let bbA:Array = bb.map { (insedeBA) -> String in
            if insedeBA.hasPrefix(" "){
                let insedeBAGET = insedeBA.substring(from: insedeBA.index(after: insedeBA.startIndex))
                
                return insedeBAGET
            }else{
                return insedeBA
            }
            
            
        }
        
        //去除""
        let bbB:Array = bbA.map { (insideB) -> String in
            let bbGet = insideB.substring(from: insideB.index(after: insideB.startIndex))
            let bbGet2 = bbGet.substring(to: bbGet.index(before: bbGet.endIndex))
            return bbGet2
        }
        
        print("array是\(bbB)")
        prefs.set(bbB, forKey: "FinalProbArray")
        self.prefs.synchronize()
        
        //
        getfirebaseLaw()

       
    }
    
    var nameAll = Array<String>()
    var contentAll = Array<String>()
    var keyAll = Array<Double>()
    
    var keyAllMaxMax = Array<Int>()
    var nameFinal = Array<String>()
    var contentFinal = Array<String>()
   
    func getfirebaseLaw(){
        FIRDatabase.database().reference().child("laws").observe(.childAdded, with: { (snapshot) in
            var matches = 0
            // Get value
            let value = snapshot.value as? NSDictionary
            print("snapshot.value是\(snapshot.value)")
            
            let name = value?["name"] as? String ?? ""
            print("name是\(name)")
            self.nameAll.append(name)
            
            let content = value?["content"] as? String ?? ""
            print("content是\(content)")
            self.contentAll.append(content)
            
            let key = value?["key"] as? [String]
            print("key是\(key)")
            
            let FinalProbArray = self.prefs.value(forKey: "FinalProbArray") as! [String]
            print ("FinalProbArray is \(FinalProbArray)")
            
           
//           //變成隨機排序一串字
//            let getRandom = FinalProbArray.sorted()
//            let becomString = getRandom.joined(separator: ",")
            
            
            //相似度
            for y in 0...FinalProbArray.count-1 {
                
                for x in 0...(key?.count)!-1{
                    
                    if FinalProbArray[y] == key?[x] {
                        matches += 1
                    }
                }
            }
            

            Double(matches) / Double(FinalProbArray.count)
            
            print("相似度是\(Double(matches) / Double(FinalProbArray.count))")
            
            //相似度集合
            self.keyAll.append(Double(Double(matches)/Double(FinalProbArray.count)))
            print("keyAll是\(self.keyAll)")
            
            let keyAllMax = self.keyAll.max()
            self.keyAllMaxMax = []
            for y in 0...self.keyAll.count-1{
                if self.keyAll[y] == keyAllMax {
                    //找到這個了
                    print("我要第\(y)比")
//                    self.LawShow.text = "\(FinalProbArray)"
                    self.keyAllMaxMax.append(y)
//                    self.LawShowLow.text = "\(self.keyAll)\n親愛的別害怕, 對方可能已經觸犯\n[ \(self.nameAll[y])]\n\n\(self.contentAll[y])\n\n"
                    
                }
            }
            
            print(" self.keyAllMax是\(self.keyAllMaxMax)")
            self.nameFinal = []
            self.contentFinal = []
            for yyy in 0...self.keyAllMaxMax.count-1{
              self.nameFinal.append(self.nameAll[self.keyAllMaxMax[yyy]])
                self.contentFinal.append(self.contentAll[self.keyAllMaxMax[yyy]])
            }
            print("self.nameFinal是\( self.nameFinal)")
            
//            self.LawShowLow.text = "親愛的別害怕, 對方可能已經觸犯\n[ \(self.nameFinal)]\n\n\(self.contentFinal)\n\n"
            
            var string1 = ""
            var string2 = ""
            
            for k in 0...self.nameFinal.count-1{
            
            string1 = string1 + "\(self.nameFinal[k])\n"
           
            string2 = string2 + "\n\(self.nameFinal[k])\n\(self.contentFinal[k])\n\n"
            }
            
            self.LawShowLow.text = "親愛的別害怕, 對方可能已經觸犯\n\(string1)\n\n\(string2)\n\n"
            
            
//            self.LawShow.text = "親愛的～這問題的確觸犯\(self.nameAll[y]),也就是說\(self.contentAll[y])"
            
        }){ (error) in
            print(error.localizedDescription)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.perpareStartUpdatingLocation()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.locationManager?.stopUpdatingLocation()
        super.viewWillDisappear(animated)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: CLLocationManagerDelegate
    private func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        self.currentAuthorizationStatus = status
    }
    
    private func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        self.currentLocation = locations.first
    }
    
    // MARK: private method
    private func perpareStartUpdatingLocation(){
        if let currentAuthorizationStatus = self.currentAuthorizationStatus, currentAuthorizationStatus == .authorizedWhenInUse || currentAuthorizationStatus == .authorizedAlways{
            self.locationManager?.startUpdatingLocation()
        }else{
            self.locationManager?.stopUpdatingLocation()
        }
    }
    
    // MARK: Table view data source
    private func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return self.results != nil ? self.results!.count : 0
        return self.results2.count
    }
    
    
    let results2 = [["name":"台北市政府警察局信義分局外事", "vicinity":"110台北市信義區信義路五段17號","phon":"+886 2 2345 1647"],["name":"台北市警察局婦幼警察隊", "vicinity":"110台北市信義區信義路五段180號","phon":"+886 2 2759 0405"],["name":"台北市政府警察局少年警察隊人事", "vicinity":"110台北市信義區信義路五段180號3樓","phon":"+886 2 2759 0827"],["name":"吳興街派出所", "vicinity":"信義區吳興街262號","phon":"+886 2 2739 8997"]]
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "LocationSearchListTableViewCell", for: indexPath as IndexPath) as! LocationSearchListTableViewCell
        let cell = tableView.dequeueReusableCell(withIdentifier: "LocationSearchListTableViewCell", for: indexPath) as? LocationSearchListTableViewCell
        
//        let cell = tableView.cellForRow(at: indexPath) as! LocationSearchListTableViewCell
        
        
       
            
            let result = self.results2[indexPath.row] as? NSDictionary
            
            if let result = result{
                
                
                cell?.nameLabel.text = result["name"] as? String
                cell?.addrLabel.text = result["vicinity"] as? String
                cell?.phonLabel.text = result["phon"] as? String
            }
        
        return cell!
    }
    
    // MARK: Table view delegate
//    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
//        if self.results == nil || self.results?.count == 0{
//            return
//        }
//        
//        if self.pageToken == nil || self.pageToken!.isEmpty{
//            return
//        }
//        
//        if indexPath.row == self.results!.count - 1{
//            self.fetechGoogleApiDataWithPageToken(pageToken: self.pageToken)
//        }
//    }
//    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let place = self.results![indexPath.row] as? NSDictionary
//        
//        if let place = place{
//            let latitude = (place.value(forKeyPath: "geometry.location.lat") as AnyObject).doubleValue
//            let longitude = (place.value(forKeyPath: "geometry.location.lng") as AnyObject).doubleValue
//            
//            let location = CLLocation(latitude: latitude!, longitude: longitude!)
//            
//            self.placesClient?.lookUpPlaceID(place["place_id"] as! String, callback: { (result , error) in
//                if let result = result{
//                    let dic = ["placeLocation": location, "GMSPlace": result]
//                    
//                    
//                }else{
//                    
////                    EZPublicFunctional.alertViewWithTitle("Oops! Something went wrong.".localized, message: error?.localizedDescription, okButtonTitle: "OK".localized)
//                }
//            })
//        }
//    }
    
   
    
//    // MARK: private method
//    func fetechGoogleApiDataWithPageToken(pageToken: String?){
//        if let pageToken = pageToken{
//            self.googleApiDataFetcher?.fetchPlaceNearByCoordinate(coordinate: self.currentLocation!.coordinate, searchTypes: self.searchType, nextPageToken: pageToken, completion: { (responseObject, error) in
//                
//                if let responseObject = responseObject as? NSDictionary{
//                    if responseObject["status"] as! String == "OK"{
//                        let arr = NSMutableArray()
//                        arr.addObjects(from: responseObject["results"] as! [AnyObject])
//                        self.results = arr.copy() as? NSArray
//                        self.pageToken = responseObject["next_page_token"] as? String
//                    }
//                    
//                }else{
////                    EZPublicFunctional.alertViewWithTitle("Oops!".localized,
////                                                          message: "There are no location information!".localized,
////                                                          okButtonTitle: "OK".localized)
//                }
//            })
//        }
//    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
